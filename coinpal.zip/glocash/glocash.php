<?php
/*
Plugin Name: WooCommerce Glocash
Plugin URI: https://www.glocash.com/
Description: Integrates your Glocash payment getway into your WooCommerce installation.
Version: 1.2
Author: Glocash
Text Domain: glocash
Author URI: https://www.glocash.com/
*/
add_action('plugins_loaded', 'init_glocash_gateway', 0);

function init_glocash_gateway() {
	if( !class_exists('WC_Payment_Gateway') )  return;
	
	require_once('class-wc-gateway-glocash.php');
	
	// Add the gateway to WooCommerce
	function add_glocash_gateway( $methods )
	{
		return array_merge($methods, 
				array(
						'WC_Gateway_Glocash'));
	}
	add_filter('woocommerce_payment_gateways', 'add_glocash_gateway' );
	
	function wc_glocash_plugin_edit_link( $links ){
		return array_merge(
				array(
						'settings' => '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wc_gateway_glocash') . '">'.__( 'Settings', 'alipay' ).'</a>'
				),
				$links
		);
	}
	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_glocash_plugin_edit_link' );
}
?>
