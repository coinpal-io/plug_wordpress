const settings = window.wc.wcSettings.getSetting( 'coinpal_data', {} );
const label = window.wp.htmlEntities.decodeEntities( settings.title ) || window.wp.i18n.__( 'Coinpal', 'wc-coinpal' );


const Content = () => {
    return window.wp.element.createElement(
        "div",
        null,
        window.wp.element.createElement("img", {
            src: "https://www.coinpal.io/images/plug_coinpal.png" ,
            alt: "",
            style: { width: "632px", height: "auto", marginBottom: "10px" }
        }),
        window.wp.htmlEntities.decodeEntities(settings.description || '')
    );
};


const Block_Gateway = {
    name: 'coinpal',
    label: label,
    content: Object( window.wp.element.createElement )( Content, null ),
    edit: Object( window.wp.element.createElement )( Content, null ),
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod( Block_Gateway );